[center][img width=16 height=16]http://www.smfpersonal.net/Adkmods/title.png[/img] [size=18pt][font=tahoma][b][color=#0489B1]Actualizando a Adk Portal 3.0 / Upgrading to Adk Portal 3.0[/color][/b][/font][/size] [img width=16 height=16]http://www.smfpersonal.net/Adkmods/title.png[/img][/center]
[hr]

[img width=16 height=16]http://www.smfpersonal.net/Adkmods/user.png[/img][b]Founder:[/b]
[img width=40 height=15]http://www.smfpersonal.net/Adkmods/tree.png[/img] [url=http://www.smfpersonal.net/profiles/lucasruroken-u1.html]Juarez, Lucas Javier (Lucas-ruroken)[/url]

[img width=16 height=16]http://www.smfpersonal.net/Adkmods/user.png[/img][b]Project Manager:[/b]
[img width=40 height=15]http://www.smfpersonal.net/Adkmods/tree.png[/img] [url=http://www.smfpersonal.net/profiles/heracles-u259.html]Clavijo, Pablo (^HeRaCLeS^)[/url]

[img width=16 height=16]http://www.smfpersonal.net/Adkmods/user.png[/img][b]Site Manager:[/b]
[img width=40 height=15]http://www.smfpersonal.net/Adkmods/tree.png[/img] [url=http://www.smfpersonal.net/profiles/enik-u417.html]Alfaro Garcia, Marco Antonio (Enik)[/url]

[img width=16 height=16]http://www.smfpersonal.net/Adkmods/user.png[/img][b]Developers:[/b]
[img width=40 height=15]http://www.smfpersonal.net/Adkmods/tree.png[/img] [url=http://www.smfpersonal.net/profiles/heracles-u259.html]Clavijo, Pablo (^HeRaCLeS^)[/url]
[img width=40 height=15]http://www.smfpersonal.net/Adkmods/tree.png[/img] [url=http://www.smfpersonal.net/profiles/lucasruroken-u1.html]Juarez, Lucas Javier (Lucas-ruroken)[/url]

[hr]
[url=http://creativecommons.org/licenses/by/3.0][img]http://i.creativecommons.org/l/by/3.0/80x15.png[/img][/url]
Esta obra est� bajo una [url=http://creativecommons.org/licenses/by/3.0]licencia Creative Commons Atribuci�n 3.0 Unported[/url]
This work is licensed under a [url=http://creativecommons.org/licenses/by/3.0]Creative Commons Attribution 3.0 Unported License[/url]
