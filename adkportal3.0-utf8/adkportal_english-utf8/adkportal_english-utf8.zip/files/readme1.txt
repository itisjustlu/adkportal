[center][url=http://www.smfpersonal.net][img]http://www.smfpersonal.net/Adkmods/adk-team.png[/img][/url][/center]
[center][img]http://www.smfpersonal.net/Adkmods/title.png[/img] [size=18pt][font=tahoma][b][color=#006666]English utf8 Adk Portal 3.0[/color][/b][/font][/size] [img]http://www.smfpersonal.net/Adkmods/title.png[/img][/center]
[hr]

[center][size=18pt][font=tahoma][b][color=#006666]Gracias por haber usado English utf8 Adk Portal 3.0[/color][/b][/font][/size][/center]
[center][size=18pt][font=tahoma][b][color=#006666]Thanks for using English utf8 Adk Portal 3.0[/color][/b][/font][/size][/center]

