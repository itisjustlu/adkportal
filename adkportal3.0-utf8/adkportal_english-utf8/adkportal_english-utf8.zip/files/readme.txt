[center][url=http://www.smfpersonal.net][img]http://www.smfpersonal.net/Adkmods/adk-team.png[/img][/url][/center]
[center][img]http://www.smfpersonal.net/Adkmods/title.png[/img] [size=18pt][font=tahoma][b][color=#006666]English utf8 Adk Portal 3.0[/color][/b][/font][/size] [img]http://www.smfpersonal.net/Adkmods/title.png[/img][/center]
[hr]
[img]http://www.smfpersonal.net/Adkmods/user.png[/img][b]Author:[/b] [color=#FE2E9A] [b][url=http://www.smfpersonal.net/profiles/heracles-u259.html]^HeRaCLeS^[/url][/b][/color]

[img]http://www.smfpersonal.net/Adkmods/star.png[/img] [b]Developer:[/b] [url=http://www.smfpersonal.net/]Adk Team[/url]

[hr]

[center][size=18pt][font=tahoma][b][color=#006666]Gracias por instalar English utf8 Adk Portal 3.0[/color][/b][/font][/size][/center]
[center][size=18pt][font=tahoma][b][color=#006666]Thank you for installing English utf8 Adk Portal 3.0[/color][/b][/font][/size][/center]

[hr]
[url=http://creativecommons.org/licenses/by/3.0][img]http://i.creativecommons.org/l/by/3.0/80x15.png[/img][/url]
Esta obra est� bajo una [url=http://creativecommons.org/licenses/by/3.0]licencia Creative Commons Atribuci�n 3.0 Unported[/url]
This work is licensed under a [url=http://creativecommons.org/licenses/by/3.0]Creative Commons Attribution 3.0 Unported License[/url]
