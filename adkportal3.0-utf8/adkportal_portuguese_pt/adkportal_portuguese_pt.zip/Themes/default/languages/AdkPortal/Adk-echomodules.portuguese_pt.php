<?php
/**
 * Adk Portal
 * Version: 3.0
 * Official support: http://www.smfpersonal.net
 * Author: Adk Team
 * Copyright: 2009 - 2014 � SMFPersonal
 * Developers:
 * 		Juarez, Lucas Javier
 * 		Clavijo, Pablo
 * Translate PT By Candidosa2 Support www.smfpt.net
 * version smf 2.0*
 */

$txt['adkmodules_shouts'] = 'Mensagens do Shoutbox';
$txt['adkmodules_autor'] = 'Autor';
$txt['adkmodules_date'] = 'Data';
$txt['adkmodules_credits'] = 'Cr&eacute;ditos - Adk portal SMF Personal';
$txt['adkmodules_email'] = 'E-mail';
$txt['adkmodules_name'] = 'Nome';
$txt['adkmodules_remove_message'] = 'Voc&ecirc; quer apagar essa hist&oacute;ria? Esta opera&ccedil;&atilde;o n&atilde;o pode voltar';
$txt['adkmodules_credits_01'] = 'Descri&ccedil;&atilde;o resumida';
$txt['adkmodules_credits_02'] = '<b>Adk portal</b> &eacute; um portal integrado ao SMF, com v&aacute;rias extens&otilde;es e recursos.';
$txt['adkmodules_credits_03'] = 'O portal tem como objetivo simples e intuitiva para o Administrador.';
$txt['adkmodules_credits_04'] = 'Ele tem todas as caracter&icirc;sticas de portal, al&eacute;m de ter um grande conjunto de transfer&ecirc;ncias, sistema de p&aacute;ginas internas, etc.';
$txt['adkmodules_credits_05'] = 'Cr&eacute;ditos';
$txt['adkmodules_credits_06'] = '<b>SMFPersonal</b> quero agradecer a todos que ajudaram a fazer <b>Adk Portal</b> o que &eacute; hoje.';
$txt['adkmodules_credits_07'] = 'Para <b>Utilizadores</b> selecionando diariamente.';
$txt['adkmodules_credits_08'] = 'Para <b>Tradutores</b> que eles possam fazer a leitura do mundo.';
$txt['adkmodules_credits_09'] = 'Para <b>Testers</b> eles est&atilde;o inquietos por erros.';
$txt['adkmodules_credits_10'] = 'Para <b>Amigos</b> eles nos deram o seu apoio incondicional.';
$txt['adkmodules_credits_11'] = 'Equipe';
$txt['adkmodules_credits_12'] = 'Agradecimentos Especiais';
$txt['adkmodules_form_send_content'] = 'Conte&uacute;do da Mensagem';
$txt['adkmodules_form_sendeded'] = 'Mensagem enviada. obrigado';
$txt['adkmodules_form_send_all'] = 'Enviar dados';
$txt['adkmodules_form_select_admin'] = 'Administrador';
$txt['adkmodules_form_contact'] = 'Formul&aacute;rio de contacto';
$txt['adkmodules_index_pages'] = '&icirc;ndice de p&aacute;gina';

?>